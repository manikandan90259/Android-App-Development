package com.example.todoapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etNewTask;
    Button btnAdd, btnLogout;
    ListView lvTasks;

    DatabaseHelper db;
    String currentUser;
    ArrayList<String> taskList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the active session
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        currentUser = prefs.getString("USERNAME", null);

        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        db = new DatabaseHelper(this);
        etNewTask = findViewById(R.id.etNewTask);
        btnAdd = findViewById(R.id.btnAdd);
        btnLogout = findViewById(R.id.btnLogout);
        lvTasks = findViewById(R.id.lvTasks);

        loadTasks();

        // Add Task
        btnAdd.setOnClickListener(v -> {
            String taskText = etNewTask.getText().toString();
            if (!taskText.isEmpty()) {
                if (db.insertTask(currentUser, taskText)) {
                    etNewTask.setText("");
                    loadTasks();
                } else {
                    Toast.makeText(this, "Error adding task", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Delete Task (Long Press)
        lvTasks.setOnItemLongClickListener((parent, view, position, id) -> {
            String taskToDelete = taskList.get(position);

            new AlertDialog.Builder(this)
                    .setTitle("Delete Task")
                    .setMessage("Are you sure you want to delete this task permanently?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        db.deleteTask(currentUser, taskToDelete);
                        loadTasks();
                        Toast.makeText(this, "Task Deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        });

        // Logout System
        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void loadTasks() {
        taskList = db.getTasksForUser(currentUser);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        lvTasks.setAdapter(adapter);
    }
}